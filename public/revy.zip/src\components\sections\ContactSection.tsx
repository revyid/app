import { Mail, Globe, Phone, Calendar, Twitter, Linkedin } from 'lucide-react';
import { SectionLabel } from '@/components/shared/SectionLabel';
import { usePortfolioStore } from '@/stores/portfolio-store';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Mail, Globe, Phone, Calendar, Twitter, Linkedin,
};

function obfuscateEmail(email: string): string {
  return email.split('').map(c => `&#${c.charCodeAt(0)};`).join('');
}

export function ContactSection() {
  const data = usePortfolioStore((s) => s.data);
  return (
    <div className="mb-6">
      <SectionLabel text="Contact" />
      <div className="space-y-2">
        {data.contacts.map((contact) => {
          const IconComponent = iconMap[contact.icon] || Mail;
          const isEmail = contact.type === 'email';
          return (
            <a
              key={contact.id}
              href={contact.href}
              className="flex items-center gap-3 text-body-sm text-foreground hover:text-primary hover:translate-x-1 active:scale-[0.97] transition-all duration-200 py-1 min-w-0"
            >
              <div className="w-8 h-8 rounded-[8px] bg-surface-variant flex items-center justify-center">
                <IconComponent className="w-4 h-4 text-muted-foreground" />
              </div>
              {isEmail ? (
                <span className="truncate" dangerouslySetInnerHTML={{ __html: obfuscateEmail(contact.value) }} />
              ) : (
                <span className="truncate">{contact.value}</span>
              )}
            </a>
          );
        })}
      </div>
    </div>
  );
}
