import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const runtime = 'nodejs';

function getSupabase() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
}

const ALLOWED_ORIGINS = ['https://revy.my.id', 'https://dev.revy.my.id'];

function getCorsHeaders(origin: string) {
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0],
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-api-key',
  };
}

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function validateApiKey(apiKey: string) {
  const supabase = getSupabase();

  // Check site key first
  const { data: siteKeyRow } = await supabase
    .from('site_settings').select('value').eq('key', 'site_api_key').single();
  if (siteKeyRow?.value && apiKey === siteKeyRow.value) {
    return { valid: true, userId: null, keyId: null, isSiteKey: true };
  }

  const keyHash = await sha256Hex(apiKey);
  const { data } = await supabase.rpc('validate_api_key_for_shorten', { p_key_hash: keyHash });

  if (!data?.valid) {
    return { valid: false };
  }

  return { valid: true, userId: data.user_id, keyId: data.key_id, isSiteKey: false };
}

export async function OPTIONS(request: Request) {
  const origin = request.headers.get('origin') || '';
  return new Response(null, { status: 204, headers: getCorsHeaders(origin) });
}

export async function GET(request: Request) {
  const origin = request.headers.get('origin') || '';
  const cors = getCorsHeaders(origin);
  const url = new URL(request.url);
  const slug = url.searchParams.get('slug');
  const apiKey = request.headers.get('x-api-key');

  if (!apiKey) {
    return NextResponse.json({ error: 'API key required' }, { status: 401, headers: cors });
  }

  const auth = await validateApiKey(apiKey);
  if (!auth.valid) {
    return NextResponse.json({ error: 'Invalid API key' }, { status: 401, headers: cors });
  }

  const supabase = getSupabase();

  // List mode
  if (!slug) {
    const { data } = await supabase.rpc('list_short_urls', { p_user_id: auth.userId });
    return NextResponse.json({ urls: data }, { headers: cors });
  }

  // Stats mode
  const { data } = await supabase.rpc('get_short_url_stats', { p_user_id: auth.userId, p_slug: slug });

  if (data?.error) {
    return NextResponse.json({ error: data.error }, { status: 404, headers: cors });
  }

  return NextResponse.json(data, { headers: cors });
}

export async function POST(request: Request) {
  const origin = request.headers.get('origin') || '';
  const cors = getCorsHeaders(origin);
  const apiKey = request.headers.get('x-api-key');

  if (!apiKey) {
    return NextResponse.json({ error: 'API key required' }, { status: 401, headers: cors });
  }

  const auth = await validateApiKey(apiKey);
  if (!auth.valid) {
    return NextResponse.json({ error: 'Invalid API key' }, { status: 401, headers: cors });
  }

  // Site key: find admin user to use as owner
  let userId = auth.userId;
  let keyId = auth.keyId;
  if (!userId) {
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
    const { data: admin } = await supabase.from('app_users').select('id').eq('is_admin', true).limit(1).single();
    if (admin) {
      userId = admin.id;
      // Use first active API key of admin
      const { data: adminKey } = await supabase.from('api_keys').select('id').eq('user_id', admin.id).eq('is_active', true).limit(1).single();
      keyId = adminKey?.id || null;
    }
  }

  let body: any;
  try {
    const text = await request.text();
    if (!text || text.trim() === '') {
      return NextResponse.json({ error: 'Empty request body' }, { status: 400, headers: cors });
    }
    body = JSON.parse(text);
  } catch (e: any) {
    return NextResponse.json({ error: 'Invalid JSON: ' + (e.message || 'parse error') }, { status: 400, headers: cors });
  }

  const { url, slug } = body;

  if (!url) {
    return NextResponse.json({ error: 'Missing url' }, { status: 400, headers: cors });
  }

  const supabase = getSupabase();

  // Validate URL directly
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    return NextResponse.json({ error: 'Invalid URL (must start with http:// or https://)' }, { status: 400, headers: cors });
  }

  // Generate or validate slug
  let finalSlug = slug;
  if (!finalSlug) {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let s = '';
    for (let i = 0; i < 7; i++) s += chars[Math.floor(Math.random() * chars.length)];
    finalSlug = s;
  } else {
    finalSlug = finalSlug.toLowerCase().replace(/[^a-z0-9-]/g, '');
    if (finalSlug.length < 3 || finalSlug.length > 16) {
      return NextResponse.json({ error: 'Slug must be 3-16 alphanumeric characters' }, { status: 400, headers: cors });
    }
  }

  // Check if slug exists
  const { data: existing } = await supabase.from('short_urls').select('id').eq('slug', finalSlug).single();
  if (existing) {
    return NextResponse.json({ error: 'Slug already taken' }, { status: 400, headers: cors });
  }

  // Insert
  const { data: inserted, error: insertError } = await supabase.from('short_urls').insert({
    slug: finalSlug,
    original_url: url,
    user_id: userId,
    api_key_id: keyId,
  }).select().single();

  if (insertError) {
    return NextResponse.json({ error: insertError.message }, { status: 500, headers: cors });
  }

  return NextResponse.json({
    id: inserted.id,
    slug: inserted.slug,
    short_url: `https://revy.my.id/s/${inserted.slug}`,
    original_url: inserted.original_url,
    created_at: inserted.created_at,
  }, { status: 201, headers: cors });
}

export async function DELETE(request: Request) {
  const origin = request.headers.get('origin') || '';
  const cors = getCorsHeaders(origin);
  const url = new URL(request.url);
  const slug = url.searchParams.get('slug');
  const apiKey = request.headers.get('x-api-key');

  if (!slug) {
    return NextResponse.json({ error: 'Missing ?slug=' }, { status: 400, headers: cors });
  }
  if (!apiKey) {
    return NextResponse.json({ error: 'API key required' }, { status: 401, headers: cors });
  }

  const auth = await validateApiKey(apiKey);
  if (!auth.valid) {
    return NextResponse.json({ error: 'Invalid API key' }, { status: 401, headers: cors });
  }

  const supabase = getSupabase();

  // Admin (site key) can delete any; user key can only delete own
  let query = supabase.from('short_urls').delete().eq('slug', slug);
  if (!auth.isSiteKey && auth.userId) {
    query = query.eq('user_id', auth.userId);
  }

  const { error, count } = await query;
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500, headers: cors });
  }

  return NextResponse.json({ ok: true, deleted: true }, { headers: cors });
}

export async function PATCH(request: Request) {
  const origin = request.headers.get('origin') || '';
  const cors = getCorsHeaders(origin);
  const url = new URL(request.url);
  const slug = url.searchParams.get('slug');
  const apiKey = request.headers.get('x-api-key');

  if (!slug) return NextResponse.json({ error: 'Missing ?slug=' }, { status: 400, headers: cors });
  if (!apiKey) return NextResponse.json({ error: 'API key required' }, { status: 401, headers: cors });

  const auth = await validateApiKey(apiKey);
  if (!auth.valid) return NextResponse.json({ error: 'Invalid API key' }, { status: 401, headers: cors });

  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400, headers: cors });
  }

  const { url: newUrl, new_slug: newSlug } = body;

  if (!newUrl) return NextResponse.json({ error: 'Missing url' }, { status: 400, headers: cors });
  if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
    return NextResponse.json({ error: 'Invalid URL (must start with http:// or https://)' }, { status: 400, headers: cors });
  }

  const supabase = getSupabase();
  const updates: any = { original_url: newUrl };

  if (newSlug) {
    const cleaned = newSlug.toLowerCase().replace(/[^a-z0-9-]/g, '');
    if (cleaned.length < 3 || cleaned.length > 16) {
      return NextResponse.json({ error: 'Slug must be 3–16 alphanumeric characters' }, { status: 400, headers: cors });
    }
    // Check slug not taken by another record
    const { data: existing } = await supabase.from('short_urls').select('id').eq('slug', cleaned).neq('slug', slug).single();
    if (existing) return NextResponse.json({ error: 'Slug already taken' }, { status: 400, headers: cors });
    updates.slug = cleaned;
  }

  let query = supabase.from('short_urls').update(updates).eq('slug', slug);
  if (!auth.isSiteKey && auth.userId) query = query.eq('user_id', auth.userId);

  const { error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500, headers: cors });

  return NextResponse.json({ ok: true }, { headers: cors });
}
