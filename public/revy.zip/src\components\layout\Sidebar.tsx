'use client';

import { useState, useRef, type ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, MessageCircle, User } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useModeAnimation, ThemeAnimationType } from 'react-theme-switch-animation';
import { useThemeStore } from '@/stores/theme-store';

interface SidebarProps {
  children: ReactNode;
  showFooter?: boolean;
  showMobile?: boolean;
  onChatClick?: () => void;
  onProfileClick?: () => void;
}

function SidebarFooter({ onChatClick, onProfileClick }: { onChatClick?: () => void; onProfileClick?: () => void }) {
  const effectiveTheme = useThemeStore((s) => s.effectiveTheme);
  const setTheme = useThemeStore((s) => s.setTheme);
  const { user } = useAuth();
  const isDark = effectiveTheme === 'dark';
  const userToggledRef = useRef(false);

  const { ref, toggleSwitchTheme } = useModeAnimation({
    animationType: ThemeAnimationType.CIRCLE,
    duration: 750,
    isDarkMode: isDark,
    onDarkModeChange: (dark: boolean) => {
      if (!userToggledRef.current) return;
      userToggledRef.current = false;
      const current = useThemeStore.getState().theme;
      if (current === 'system') return;
      setTheme(dark ? 'dark' : 'light');
    },
  });

  return (
    <div className="mt-auto pt-3 border-t border-outline/15">
      <div className="flex items-center justify-center gap-1">
        <button onClick={onChatClick} className="w-9 h-9 rounded-xl flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-surface-variant/50 transition-colors" aria-label="Chat">
          <MessageCircle className="w-[18px] h-[18px]" />
        </button>
        <button ref={ref} onClick={() => { userToggledRef.current = true; toggleSwitchTheme(); }} className="w-9 h-9 rounded-xl flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-surface-variant/50 transition-colors" aria-label="Toggle theme">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            {isDark ? <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" /> : (
              <>
                <circle cx="12" cy="12" r="5" />
                <line x1="12" y1="1" x2="12" y2="3" />
                <line x1="12" y1="21" x2="12" y2="23" />
                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                <line x1="1" y1="12" x2="3" y2="12" />
                <line x1="21" y1="12" x2="23" y2="12" />
                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
              </>
            )}
          </svg>
        </button>
        <button onClick={onProfileClick} className="w-9 h-9 rounded-xl flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-surface-variant/50 transition-colors overflow-hidden" aria-label="Profile">
          {user?.avatar_url ? (
            <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
          ) : (
            <User className="w-[18px] h-[18px]" />
          )}
        </button>
      </div>
    </div>
  );
}

export function Sidebar({ children, showFooter = false, showMobile = true, onChatClick, onProfileClick }: SidebarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block fixed left-8 top-4 bottom-4 w-72 z-10">
        <div className="h-full flex items-center">
          <div className="squircle-card bg-surface border border-outline/20 p-4 space-y-2.5 noise-grain shadow-fluid w-full h-full overflow-y-auto overflow-x-hidden scrollbar-thin flex flex-col">
            <div className="space-y-2.5 flex-1 flex flex-col">
              {children}
            </div>
            {showFooter && <SidebarFooter onChatClick={onChatClick} onProfileClick={onProfileClick} />}
          </div>
        </div>
      </aside>

      {/* Desktop spacer */}
      <div className="hidden lg:block w-80 flex-shrink-0" />

      {/* Mobile menu button */}
      {showMobile && (
        <button
          onClick={() => setMobileOpen(true)}
          className="lg:hidden fixed top-4 left-4 z-50 p-2.5 rounded-full bg-surface border border-outline/20 shadow-elevation-2 active:scale-95 transition-transform"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5 text-foreground" />
        </button>
      )}

      {/* Mobile drawer */}
      {showMobile && (
        <AnimatePresence>
          {mobileOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                onClick={() => setMobileOpen(false)}
                className="lg:hidden fixed inset-0 z-50 bg-black/40"
              />
              <motion.aside
                initial={{ x: '-100%' }}
                animate={{ x: 0 }}
                exit={{ x: '-100%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="lg:hidden fixed left-0 top-0 bottom-0 w-80 max-w-[85vw] z-50 bg-surface border-r border-outline/20 overflow-y-auto"
              >
                <div className="p-4 space-y-2.5">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-title-sm font-semibold text-foreground">Menu</span>
                    <button onClick={() => setMobileOpen(false)} className="p-1.5 rounded-full hover:bg-surface-variant transition-colors" aria-label="Close menu">
                      <X className="w-5 h-5 text-muted-foreground" />
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {children}
                  </div>
                  {showFooter && <SidebarFooter onChatClick={onChatClick} onProfileClick={onProfileClick} />}
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>
      )}
    </>
  );
}
